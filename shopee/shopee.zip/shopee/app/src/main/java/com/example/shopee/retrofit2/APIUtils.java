package com.example.shopee.retrofit2;
public class APIUtils {
    public  static final String Base_Url="http://192.168.1.14/test/api/";
    public static DataClient getData(){
        return RetrofitClient.getClient(Base_Url).create(DataClient.class);
    }
}