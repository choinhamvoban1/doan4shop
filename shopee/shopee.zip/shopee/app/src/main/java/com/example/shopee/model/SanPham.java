package com.example.shopee.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class SanPham {

    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("TenSp")
    @Expose
    private String tenSp;
    @SerializedName("GiaSp")
    @Expose
    private Integer giaSp;
    @SerializedName("SoLuong")
    @Expose
    private Integer soLuong;
    @SerializedName("DonGia")
    @Expose
    private Integer donGia;
    @SerializedName("Size")
    @Expose
    private String size;
    @SerializedName("MoTa")
    @Expose
    private String moTa;
    @SerializedName("HinhAnh")
    @Expose
    private String hinhAnh;

    public SanPham(Integer id, String tenSp, Integer giaSp, Integer soLuong, Integer donGia, String size, String moTa, String hinhAnh) {
        this.id = id;
        this.tenSp = tenSp;
        this.giaSp = giaSp;
        this.soLuong = soLuong;
        this.donGia = donGia;
        this.size = size;
        this.moTa = moTa;
        this.hinhAnh = hinhAnh;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTenSp() {
        return tenSp;
    }

    public void setTenSp(String tenSp) {
        this.tenSp = tenSp;
    }

    public Integer getGiaSp() {
        return giaSp;
    }

    public void setGiaSp(Integer giaSp) {
        this.giaSp = giaSp;
    }

    public Integer getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(Integer soLuong) {
        this.soLuong = soLuong;
    }

    public Integer getDonGia() {
        return donGia;
    }

    public void setDonGia(Integer donGia) {
        this.donGia = donGia;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getMoTa() {
        return moTa;
    }

    public void setMoTa(String moTa) {
        this.moTa = moTa;
    }

    public String getHinhAnh() {
        return hinhAnh;
    }

    public void setHinhAnh(String hinhAnh) {
        this.hinhAnh = hinhAnh;
    }

}