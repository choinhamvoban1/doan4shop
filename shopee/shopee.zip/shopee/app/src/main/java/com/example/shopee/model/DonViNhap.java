package com.example.shopee.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class DonViNhap {

    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("tendv")
    @Expose
    private String tendv;
    @SerializedName("diachi")
    @Expose
    private String diachi;

    public DonViNhap(Integer id, String tendv, String diachi) {
        this.id = id;
        this.tendv = tendv;
        this.diachi = diachi;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTendv() {
        return tendv;
    }

    public void setTendv(String tendv) {
        this.tendv = tendv;
    }

    public String getDiachi() {
        return diachi;
    }

    public void setDiachi(String diachi) {
        this.diachi = diachi;
    }

}