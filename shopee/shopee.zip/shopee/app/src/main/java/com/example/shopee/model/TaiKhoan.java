package com.example.shopee.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class TaiKhoan {

    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("taikhoan")
    @Expose
    private String taikhoan;
    @SerializedName("matkhau")
    @Expose
    private String matkhau;
    @SerializedName("sodienthoai")
    @Expose
    private String sodienthoai;
    @SerializedName("diachi")
    @Expose
    private String diachi;
    @SerializedName("hoten")
    @Expose
    private String hoten;
    @SerializedName("hinhanh")
    @Expose
    private String hinhanh;

    public TaiKhoan(Integer id, String taikhoan, String matkhau, String sodienthoai, String diachi, String hoten, String hinhanh) {
        this.id = id;
        this.taikhoan = taikhoan;
        this.matkhau = matkhau;
        this.sodienthoai = sodienthoai;
        this.diachi = diachi;
        this.hoten = hoten;
        this.hinhanh = hinhanh;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTaikhoan() {
        return taikhoan;
    }

    public void setTaikhoan(String taikhoan) {
        this.taikhoan = taikhoan;
    }

    public String getMatkhau() {
        return matkhau;
    }

    public void setMatkhau(String matkhau) {
        this.matkhau = matkhau;
    }

    public String getSodienthoai() {
        return sodienthoai;
    }

    public void setSodienthoai(String sodienthoai) {
        this.sodienthoai = sodienthoai;
    }

    public String getDiachi() {
        return diachi;
    }

    public void setDiachi(String diachi) {
        this.diachi = diachi;
    }

    public String getHoten() {
        return hoten;
    }

    public void setHoten(String hoten) {
        this.hoten = hoten;
    }

    public String getHinhanh() {
        return hinhanh;
    }

    public void setHinhanh(String hinhanh) {
        this.hinhanh = hinhanh;
    }

}
