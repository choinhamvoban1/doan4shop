package com.example.shopee.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class HoaDonNhap {

    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("iddonvinhap")
    @Expose
    private Integer iddonvinhap;
    @SerializedName("tongtien")
    @Expose
    private Integer tongtien;
    @SerializedName("tendv")
    @Expose
    private String tendv;
    @SerializedName("ngaylaphd")
    @Expose
    private String ngaylaphd;

    public HoaDonNhap(Integer id, Integer iddonvinhap, Integer tongtien, String tendv, String ngaylaphd) {
        this.id = id;
        this.iddonvinhap = iddonvinhap;
        this.tongtien = tongtien;
        this.tendv = tendv;
        this.ngaylaphd = ngaylaphd;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getIddonvinhap() {
        return iddonvinhap;
    }

    public void setIddonvinhap(Integer iddonvinhap) {
        this.iddonvinhap = iddonvinhap;
    }

    public Integer getTongtien() {
        return tongtien;
    }

    public void setTongtien(Integer tongtien) {
        this.tongtien = tongtien;
    }

    public String getTendv() {
        return tendv;
    }

    public void setTendv(String tendv) {
        this.tendv = tendv;
    }

    public String getNgaylaphd() {
        return ngaylaphd;
    }

    public void setNgaylaphd(String ngaylaphd) {
        this.ngaylaphd = ngaylaphd;
    }

}