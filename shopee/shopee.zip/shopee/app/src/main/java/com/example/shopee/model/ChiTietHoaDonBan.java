package com.example.shopee.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ChiTietHoaDonBan {

    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("idsanpham")
    @Expose
    private Integer idsanpham;
    @SerializedName("idhoadon")
    @Expose
    private Integer idhoadon;
    @SerializedName("soluong")
    @Expose
    private Integer soluong;
    @SerializedName("dongia")
    @Expose
    private Integer dongia;
    @SerializedName("thanhtien")
    @Expose
    private Integer thanhtien;

    public ChiTietHoaDonBan(Integer id, Integer idsanpham, Integer idhoadon, Integer soluong, Integer dongia, Integer thanhtien) {
        this.id = id;
        this.idsanpham = idsanpham;
        this.idhoadon = idhoadon;
        this.soluong = soluong;
        this.dongia = dongia;
        this.thanhtien = thanhtien;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getIdsanpham() {
        return idsanpham;
    }

    public void setIdsanpham(Integer idsanpham) {
        this.idsanpham = idsanpham;
    }

    public Integer getIdhoadon() {
        return idhoadon;
    }

    public void setIdhoadon(Integer idhoadon) {
        this.idhoadon = idhoadon;
    }

    public Integer getSoluong() {
        return soluong;
    }

    public void setSoluong(Integer soluong) {
        this.soluong = soluong;
    }

    public Integer getDongia() {
        return dongia;
    }

    public void setDongia(Integer dongia) {
        this.dongia = dongia;
    }

    public Integer getThanhtien() {
        return thanhtien;
    }

    public void setThanhtien(Integer thanhtien) {
        this.thanhtien = thanhtien;
    }

}