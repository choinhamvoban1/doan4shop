package com.example.shopee.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class QuangCao {

    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("hinhanh")
    @Expose
    private String hinhanh;
    @SerializedName("idsanpham")
    @Expose
    private Integer idsanpham;

    public QuangCao(Integer id, String hinhanh, Integer idsanpham) {
        this.id = id;
        this.hinhanh = hinhanh;
        this.idsanpham = idsanpham;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getHinhanh() {
        return hinhanh;
    }

    public void setHinhanh(String hinhanh) {
        this.hinhanh = hinhanh;
    }

    public Integer getIdsanpham() {
        return idsanpham;
    }

    public void setIdsanpham(Integer idsanpham) {
        this.idsanpham = idsanpham;
    }

}
