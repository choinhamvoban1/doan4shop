package com.example.shopee.retrofit2;

import java.util.ArrayList;
import java.util.List;

import okhttp3.MultipartBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Query;

public interface DataClient {


}





















// đối với upload dạng hình ảnh hay bất cứ thứ gì ngoài String hay số thì dùng multipart
//    @Multipart
//    @POST("http://192.168.1.14/test/api/uploadhinh.php") // gọi đến file php thực hiện chức năng này
//    Call<String> UploadPhoto(@Part MultipartBody.Part photo);
//
//    @FormUrlEncoded
//    @POST("http://192.168.1.14/test/api/insert.php")
//    Call<String> InsertData(
//            @Field("ten") String ten,
//            @Field("hinhanh") String hinhanh);
//    @FormUrlEncoded
//    @POST("loaddulieu.php")
//    Call<List<person>> loaddulieu(@Field("key") String key);
//
//
//    //    @GET("delete.php")
////    Call<String> xoadulieu(@Query("ten") String ten, // nối chuỗi vào đường link dưới phương thức của get
////                           @Query("hinhanh") String hinhanh);
//    @FormUrlEncoded
//    @POST("delete.php")
//    Call<String> xoadulieu(@Field("ten") String ten,
//                           @Field("hinhanh") String hinhanh);
//    @FormUrlEncoded
//    @POST("update.php")
//    Call<String> updatedulieu(@Field("ten") String ten,
//                              @Field("hinhanh") String hinhanh);
//
//    @FormUrlEncoded
//    @POST("timkiem.php")
//    Call<String> timkiem(@Field("ten") String ten);