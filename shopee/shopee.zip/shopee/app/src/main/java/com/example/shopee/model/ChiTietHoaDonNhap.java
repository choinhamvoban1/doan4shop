package com.example.shopee.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ChiTietHoaDonNhap {

    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("idhoadonnhap")
    @Expose
    private Integer idhoadonnhap;
    @SerializedName("idsanpham")
    @Expose
    private Integer idsanpham;
    @SerializedName("soluong")
    @Expose
    private Integer soluong;
    @SerializedName("dongia")
    @Expose
    private Integer dongia;
    @SerializedName("thanhtien")
    @Expose
    private Integer thanhtien;

    public ChiTietHoaDonNhap(Integer id, Integer idhoadonnhap, Integer idsanpham, Integer soluong, Integer dongia, Integer thanhtien) {
        this.id = id;
        this.idhoadonnhap = idhoadonnhap;
        this.idsanpham = idsanpham;
        this.soluong = soluong;
        this.dongia = dongia;
        this.thanhtien = thanhtien;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getIdhoadonnhap() {
        return idhoadonnhap;
    }

    public void setIdhoadonnhap(Integer idhoadonnhap) {
        this.idhoadonnhap = idhoadonnhap;
    }

    public Integer getIdsanpham() {
        return idsanpham;
    }

    public void setIdsanpham(Integer idsanpham) {
        this.idsanpham = idsanpham;
    }

    public Integer getSoluong() {
        return soluong;
    }

    public void setSoluong(Integer soluong) {
        this.soluong = soluong;
    }

    public Integer getDongia() {
        return dongia;
    }

    public void setDongia(Integer dongia) {
        this.dongia = dongia;
    }

    public Integer getThanhtien() {
        return thanhtien;
    }

    public void setThanhtien(Integer thanhtien) {
        this.thanhtien = thanhtien;
    }

}