package com.example.shopee.model;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class HoaDonBan {

    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("IdTaiKhoan")
    @Expose
    private Integer idTaiKhoan;
    @SerializedName("TongTien")
    @Expose
    private Integer tongTien;
    @SerializedName("HoTen")
    @Expose
    private String hoTen;
    @SerializedName("NgayLapHd")
    @Expose
    private String ngayLapHd;

    public HoaDonBan(Integer id, Integer idTaiKhoan, Integer tongTien, String hoTen, String ngayLapHd) {
        this.id = id;
        this.idTaiKhoan = idTaiKhoan;
        this.tongTien = tongTien;
        this.hoTen = hoTen;
        this.ngayLapHd = ngayLapHd;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getIdTaiKhoan() {
        return idTaiKhoan;
    }

    public void setIdTaiKhoan(Integer idTaiKhoan) {
        this.idTaiKhoan = idTaiKhoan;
    }

    public Integer getTongTien() {
        return tongTien;
    }

    public void setTongTien(Integer tongTien) {
        this.tongTien = tongTien;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public String getNgayLapHd() {
        return ngayLapHd;
    }

    public void setNgayLapHd(String ngayLapHd) {
        this.ngayLapHd = ngayLapHd;
    }

}